# Enterprise Device Status Log & Telemetry Monitor

**Version:** 1.0.0  
**Target API:** 31 - 35  
**Minimum SDK:** 31  
**Language:** Java (Android Studio)

---

## Overview

This is a **production-grade Android application** designed for IT administrators to aggregate system runtime logs from internal enterprise applications and stream them to a centralized company logging dashboard via secure HTTP POST operations.

The application implements a **two-phase security model**:
1. **Phase 1 (Verification):** Client activation with obfuscated endpoint protection
2. **Phase 2 (Monitoring):** Real-time telemetry collection and transmission

---

## Architecture

### Core Components

#### 1. **MainActivity.java** - Service Controller Layer
- **Obfuscated Endpoint Storage:** Dynamic URL reconstruction at runtime prevents static code analysis
- **License Verification:** OkHttp-based async POST to `verify_license.php` with device identifier
- **State Persistence:** SharedPreferences for authorization tracking
- **Permission Management:** Programmatic enforcement of Notification Access & Battery Optimization settings
- **Two-Phase UI Controller:** Seamless state transitions between verification and monitoring

**Key Methods:**
- `performLicenseVerification()` - POST license key + ANDROID_ID to gateway
- `checkAndRequestPermissions()` - Validates system access requirements
- `activateToggleSwitch()` - Initiates telemetry service with WakeLock
- `handleDisconnectRequest()` - Graceful service termination

#### 2. **MyNotificationListener.java** - Persistent System Log Engine
- **NotificationListenerService Extension:** Continuous background monitoring of system notifications
- **Enterprise Package Filtering:** Whitelist-based package monitoring
- **Batch Relay System:** Asynchronous HTTP transmission with configurable batch sizes
- **WakeLock Management:** Partial wake lock ensures continuous operation despite battery optimization
- **Foreground Service:** Non-dismissible notification with persistent status tracking

**Monitored Packages (Default):**
```
com.example.testapp.internal.alpha
com.example.testapp.internal.beta
com.example.testapp.internal.gamma
com.example.testapp.internal.delta
```

**Key Methods:**
- `onNotificationPosted()` - Captures incoming notification events
- `startBatchRelayThread()` - Background thread managing async relay
- `transmitBatchToGateway()` - HTTP POST to gateway endpoint
- `createEventObject()` - Structures notification data with metadata

#### 3. **activity_main.xml** - Reactive Two-Phase View
- **Phase 1 Layout:** 
  - Activation key input field
  - Authorization action button
  - Dynamic error messaging
  - WhatsApp support intent launcher
  
- **Phase 2 Layout:**
  - Large custom toggle switch (START/STOP)
  - Live metrics display (events count, uptime)
  - Connection status indicator
  - Disconnect button for graceful shutdown

#### 4. **AndroidManifest.xml** - Service Declaration
- **Critical Permissions:**
  - `INTERNET` - Network communication
  - `WAKE_LOCK` - Continuous operation
  - `RECEIVE_BOOT_COMPLETED` - System startup integration
  - `BIND_NOTIFICATION_LISTENER_SERVICE` - Notification interception
  - `POST_NOTIFICATIONS` - Android 13+ foreground service notification

- **Service Registration:**
  - `MyNotificationListener` mapped to notification listener service type
  - Boot receiver for automatic startup

#### 5. **build.gradle** - Dependency Configuration
- **OkHttp3** v4.11.0 - Multi-threaded async HTTP client
- **Material Components** v1.11.0 - Modern UI framework
- **Gson** v2.10.1 - JSON serialization
- **AndroidX Core** v1.12.0 - Platform compatibility

---

## Security Architecture

### Endpoint Obfuscation

The base URL is **dynamically reconstructed at runtime** to prevent static code analyzers from extracting infrastructure URLs:

```java
private static final String BASE_URL_PART_1 = "https://bhoomiproperty.foodmania.us.cc/";
private static final String BASE_URL_PART_2 = "central_server/";
private String BASE_URL = BASE_URL_PART_1 + BASE_URL_PART_2;
```

**Why:** Reverse engineers cannot extract complete URLs from bytecode; string concatenation requires runtime execution analysis.

### License Verification Protocol

POST request to `BASE_URL + "verify_license.php"`:

```json
{
  "license_key": "user_input_activation_key",
  "device_id": "Settings.Secure.ANDROID_ID",
  "timestamp": 1715430780000,
  "api_version": 35
}
```

**Response Success Criteria:**
- HTTP 200 status code
- Response contains `"status":"success"` or `"authorized":true`

**State Persistence:** Authorization state saved in SharedPreferences (encrypted on Android 10+)

### Permission Enforcement

Before telemetry activation, the application **forces verification** of:

1. **Notification Access:** 
   - User must explicitly grant in Settings → Apps & notifications → Special app access → Notification access
   - Programmatically verified via `NotificationManager.isNotificationListenerAccessGranted()`

2. **Battery Optimization Exemption:**
   - Directs user to Settings → Apps & notifications → Advanced → Battery usage
   - Verified via `PowerManager.isIgnoringBatteryOptimizations()`

---

## Data Flow

### Phase 1: Client Authorization
```
User Input (Activation Key)
    ↓
MainActivity.handleAuthorizationRequest()
    ↓
OkHttpClient.POST(verify_license.php)
    ↓
Server Validation
    ↓
Save to SharedPreferences
    ↓
Switch to Phase 2
```

### Phase 2: Telemetry Collection & Transmission
```
System Notification Event
    ↓
MyNotificationListener.onNotificationPosted()
    ↓
Package Filter Check
    ↓
Extract Title, Text, Metadata
    ↓
JsonObject Creation
    ↓
Event Queue (Synchronized)
    ↓
Batch Accumulation (5 events or 10-second timeout)
    ↓
OkHttpClient.POST(gateway_receiver.php) [Async Thread]
    ↓
Gateway Server Processing
```

### JSON Payload Structure

**Single Event:**
```json
{
  "event_id": 1234567890,
  "device_id": "android_device_id_hex",
  "package_name": "com.example.testapp.internal.alpha",
  "notification_title": "System Alert",
  "notification_text": "Critical process event",
  "timestamp_ms": 1715430780000,
  "timestamp_iso8601": "2024-05-11T10:13:00.000Z",
  "api_level": 35,
  "device_model": "Pixel 6 Pro"
}
```

**Batch Transmission:**
```json
{
  "device_id": "android_device_id_hex",
  "batch_timestamp": 1715430790000,
  "event_count": 5,
  "events": [
    { ... event object 1 ... },
    { ... event object 2 ... },
    { ... event object 3 ... },
    { ... event object 4 ... },
    { ... event object 5 ... }
  ]
}
```

---

## Configuration & Customization

### Modify Monitored Packages

Edit `MyNotificationListener.java`:

```java
private static final String[] MONITORED_PACKAGES = {
    "com.yourcompany.app.module1",
    "com.yourcompany.app.module2",
    "com.yourcompany.internal.service",
    // Add more package names
};
```

### Adjust Batch Parameters

In `MyNotificationListener.java`:

```java
private static final int BATCH_SIZE = 5;              // Events per batch
private static final long RELAY_INTERVAL_MS = 10000;  // 10 seconds between relays
```

### Change WhatsApp Support Number

In `MainActivity.java`:

```java
String phoneNumber = "919876543210";  // Replace with actual support number
String message = "Hello, I need help with Enterprise Device Monitor activation.";
```

### Customize UI Colors & Fonts

Colors and styles are defined in `res/values/colors.xml` and `res/values/styles.xml`. Modify:
- `@color/background_primary`
- `@color/button_primary`
- `@color/text_primary`
- `@font/inter_bold`, `@font/inter_regular`, etc.

---

## Network Requirements

### Firewall Configuration

The application requires outbound HTTPS connectivity to:
- **License Verification:** `https://bhoomiproperty.foodmania.us.cc/central_server/verify_license.php`
- **Telemetry Gateway:** `https://bhoomiproperty.foodmania.us.cc/central_server/gateway_receiver.php`

### TLS Certificate

Uses system certificate store. Ensure target gateway uses valid SSL/TLS certificate from recognized CA.

### Connection Timeouts

- **Connection Timeout:** 15 seconds
- **Read Timeout:** 20 seconds
- **Write Timeout:** 20 seconds
- **Retry on Failure:** Enabled

---

## Permissions Explained

| Permission | Purpose | Requires User Approval |
|-----------|---------|----------------------|
| `INTERNET` | Network communication | Granted during installation |
| `WAKE_LOCK` | Continuous background operation | Granted during installation |
| `RECEIVE_BOOT_COMPLETED` | Automatic startup | Granted during installation |
| `BIND_NOTIFICATION_LISTENER_SERVICE` | Access to notifications | **Runtime - Settings UI** |
| `POST_NOTIFICATIONS` | Foreground service notification (Android 13+) | **Runtime - Implied** |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | Disable battery optimization | **Runtime - Settings Intent** |
| `ACCESS_NETWORK_STATE` | Check network connectivity | Granted during installation |

---

## Compilation & Deployment

### Prerequisites
- Android Studio 4.2 or later
- Java 11 JDK
- Gradle 7.0+

### Build Steps

1. **Clone/Import Project**
   ```bash
   # Copy source files into Android Studio project structure
   # app/src/main/java/com/enterprise/devicemonitor/
   # app/src/main/res/layout/
   # app/src/main/AndroidManifest.xml
   # app/build.gradle
   ```

2. **Sync Gradle**
   ```bash
   # In Android Studio: File → Sync Now
   ```

3. **Build APK**
   ```bash
   # Debug: Build → Build Bundle(s)/APK(s) → Build APK(s)
   # Release: Build → Generate Signed Bundle / APK
   ```

4. **Generate Release Signing Key**
   ```bash
   keytool -genkey -v -keystore release.keystore -keyalg RSA -keysize 2048 -validity 10000
   ```

### APK Signatures

Both debug and release APKs require signature verification on target devices. Enterprise deployment typically uses Mobile Device Management (MDM) solutions (MobileIron, Intune, etc.) for automated distribution.

---

## Runtime Behavior

### Service Lifecycle

**Starting:**
1. User enters activation key and taps "Authorize Client"
2. License verification POST sent to gateway
3. If successful, Phase 2 unlocked
4. User checks Notification Access in Settings
5. User optionally disables Battery Optimization
6. User taps toggle switch → Service starts
7. Foreground notification appears (persistent)
8. WakeLock acquired
9. Background relay thread spawns

**Running:**
- Monitors all system notifications in real-time
- Filters by configured package whitelist
- Batches events (5 events or 10-second intervals)
- Transmits batches asynchronously via HTTP POST
- Updates UI metrics (event count, uptime)

**Stopping:**
- User taps toggle or "Disconnect" button
- Service stops gracefully
- WakeLock released
- Foreground notification dismissed
- SharedPreferences updated

### Background Battery Optimization

If battery optimization is NOT disabled:
- Android may kill the service
- WakeLock becomes ineffective
- Notification monitoring pauses

**Solution:** Force user to disable battery optimization before activating service.

---

## Logging & Debugging

### Log Tags

Filter Logcat by tag for debugging:

```
// License verification
adb logcat | grep "MainActivity"

// Notification listener
adb logcat | grep "MyNotificationListener"

// Network operations
adb logcat | grep "OkHttp"
```

### Common Issues

| Issue | Cause | Solution |
|-------|-------|----------|
| "Server verification failed" | Network unreachable | Check internet connection, firewall rules |
| Notifications not captured | Notification Access not granted | Open Settings → Apps → Special access → Notifications |
| Service stops after 1 minute | Battery optimization enabled | Settings → Battery → Optimize → Remove app |
| "Invalid activation key" | Wrong license key format | Verify 8+ character minimum; check server-side validation |
| High battery drain | WakeLock held permanently | Normal behavior; disable Battery Optimization required |

---

## Compliance & Legal

### User Consent

This application captures and transmits notification data from monitored applications. Ensure:

1. **Privacy Policy:** Clearly states what data is collected and transmitted
2. **Enterprise Deployment:** Only deployed via MDM with user acknowledgment
3. **Data Encryption:** HTTPS transmission protects in-transit data
4. **Data Retention:** Define server-side retention policies
5. **GDPR/CCPA Compliance:** Implement data deletion mechanisms if applicable

### Security Considerations

- **No sensitive data filtering:** Application does NOT redact passwords, credentials, or PII
- **All notifications transmitted:** No client-side encryption beyond HTTPS
- **Network exposure:** Captured data visible to network administrators
- **Reverse engineering:** Obfuscation is NOT unbreakable; use ProGuard/R8 for additional hardening

---

## Support & Maintenance

### Version Updates

To update the application:

1. Increment `versionCode` and `versionName` in `build.gradle`
2. Rebuild and resign APK
3. Push to all managed devices via MDM

### Known Limitations

- **Android 12 (API 31):** Foreground service delays may occur
- **Devices with MIUI/ColorOS:** Aggressive battery optimization may override settings
- **Network proxies:** May intercept HTTPS traffic; ensure gateway certificate pinning if needed
- **Notification filtering:** Cannot distinguish system vs. user-initiated notifications

### Future Enhancements

- Certificate pinning for HTTPS security
- On-device event filtering (PII redaction)
- Encrypted local storage for offline queuing
- Custom relay server configuration UI
- Device management profile integration

---

## Code Quality

### Lint & ProGuard

Enable code obfuscation in release builds:

```gradle
buildTypes {
    release {
        minifyEnabled true
        shrinkResources true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
    }
}
```

### Thread Safety

- Event queue protected with `synchronized` blocks
- SharedPreferences thread-safe by design
- OkHttpClient internally thread-safe (reuse single instance)

---

## Files Included

```
/
├── build.gradle                    # Gradle build config + dependencies
├── AndroidManifest.xml             # Permissions & service declarations
├── activity_main.xml               # Two-phase UI layout
├── MainActivity.java               # Service controller (400+ lines)
├── MyNotificationListener.java      # Telemetry service (450+ lines)
└── README.md                       # This documentation
```

---

## License

**Internal Enterprise Use Only.** This software is proprietary and intended exclusively for authorized enterprise deployment. Unauthorized copying, distribution, or modification is prohibited.

---

**Last Updated:** May 2024  
**Maintainer:** Enterprise IT Security Team
