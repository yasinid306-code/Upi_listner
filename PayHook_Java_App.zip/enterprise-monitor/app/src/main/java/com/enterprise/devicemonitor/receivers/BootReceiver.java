package com.enterprise.devicemonitor.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.enterprise.devicemonitor.services.MyNotificationListener;

/**
 * BootReceiver - Initialized on system startup
 * Re-activates telemetry service if it was running before shutdown
 */
public class BootReceiver extends BroadcastReceiver {

    private static final String TAG = "BootReceiver";
    private static final String PREFS_NAME = "EnterpriseMonitorPrefs";
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_IS_AUTHORIZED = "is_authorized";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            Log.d(TAG, "Boot completed, checking service state");

            SharedPreferences prefs = context.getSharedPreferences(
                    PREFS_NAME, Context.MODE_PRIVATE
            );

            boolean wasRunning = prefs.getBoolean(KEY_SERVICE_RUNNING, false);
            boolean isAuthorized = prefs.getBoolean(KEY_IS_AUTHORIZED, false);

            if (wasRunning && isAuthorized) {
                Log.d(TAG, "Restarting telemetry service after boot");
                Intent serviceIntent = new Intent(context, MyNotificationListener.class);

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
        }
    }
}
