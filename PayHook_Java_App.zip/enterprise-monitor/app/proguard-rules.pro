# ProGuard rules for Enterprise Device Monitor
# This file specifies ProGuard/R8 configuration for code obfuscation, optimization, and security

# Preserve all public application classes
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider

# Preserve NotificationListenerService
-keep public class * extends android.service.notification.NotificationListenerService
-keepclassmembers class * extends android.service.notification.NotificationListenerService {
    public void onNotificationPosted(...);
    public void onNotificationRemoved(...);
}

# Keep OkHttp classes
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
-dontwarn okhttp3.**

# Keep Gson classes
-keep class com.google.gson.** { *; }
-dontwarn com.google.gson.**

# Keep AndroidX classes
-keep class androidx.** { *; }
-dontwarn androidx.**

# Keep Material Components
-keep class com.google.android.material.** { *; }
-dontwarn com.google.android.material.**

# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep constructors that are accessed via reflection
-keepclassmembers class * {
    public <init>(...);
}

# Keep callback and listener interfaces
-keep class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Keep enums
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Keep R classes
-keepclassmembers class **.R$* {
    public static <fields>;
}

# Disable logging in release builds
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

# Obfuscate class names but keep package structure
-repackageclasses 'com.enterprise.devicemonitor.obf'
-flattenpackagehierarchy

# Keep line numbers for crash reporting
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Optimize aggressive
-optimizationpasses 5
-optimizations !code/simplification/arithmetic
